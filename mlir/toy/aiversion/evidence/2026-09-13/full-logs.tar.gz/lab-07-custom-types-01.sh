${TOY_BUILD}/bin/toyc-ch7 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=mlir
