cmake --version
ninja --version
clang++ --version
python3 --version
