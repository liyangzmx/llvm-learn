${TOY_BUILD}/bin/mlir-tblgen -gen-op-decls \
  /opt/llvm-project/mlir/examples/toy/Ch2/include/toy/Ops.td \
  -I /opt/llvm-project/mlir/include
