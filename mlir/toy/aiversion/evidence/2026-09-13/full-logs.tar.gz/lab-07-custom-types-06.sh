"$TOY_BUILD/bin/toyc-ch7" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=jit > "$TOY_LAB/ch7-result.txt" 2> "$TOY_LAB/ch7-errors.txt"
