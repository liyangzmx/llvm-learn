module {
  func.func @loop() {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c3 = arith.constant 3 : index
    cf.br ^header(%c0 : index)
  ^header(%i : index):
    %cond = arith.cmpi slt, %i, %c3 : index
    cf.cond_br %cond, ^body, ^exit
  ^body:
    %next = arith.addi %i, %c1 : index
    cf.br ^header(%next : index)
  ^exit:
    return
  }
}
