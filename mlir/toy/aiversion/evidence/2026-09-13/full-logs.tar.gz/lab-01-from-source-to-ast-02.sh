test -x "$TOY_BUILD/bin/toyc-ch1"
test -x "$TOY_BUILD/bin/FileCheck"
"$TOY_BUILD/bin/toyc-ch1" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch1/ast.toy \
  -emit=ast 2> "$TOY_LAB/ch1-ast.txt"
rg -n 'Proto|VarDecl|Literal|BinOp|Call|Return' "$TOY_LAB/ch1-ast.txt"
