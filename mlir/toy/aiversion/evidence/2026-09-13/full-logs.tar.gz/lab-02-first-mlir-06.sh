"$TOY_BUILD/bin/toyc-ch2" "$TOY_LAB/ch2-generic.mlir" \
  -emit=mlir 2> "$TOY_LAB/ch2-roundtrip.mlir"
diff -u "$TOY_LAB/ch2-custom.mlir" "$TOY_LAB/ch2-roundtrip.mlir"
