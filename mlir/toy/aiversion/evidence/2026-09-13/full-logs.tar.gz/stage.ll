; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "arm64-apple-darwin24.6.0"

@nl = internal constant [2 x i8] c"\0A\00"
@frmt_spec = internal constant [4 x i8] c"%f \00"

declare !dbg !3 void @free(ptr)

declare !dbg !6 i32 @printf(ptr, ...)

declare !dbg !7 ptr @malloc(i64)

define void @main() !dbg !8 {
  %1 = call ptr @malloc(i64 ptrtoint (ptr getelementptr (double, ptr null, i64 4) to i64)), !dbg !10
  %2 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } undef, ptr %1, 0, !dbg !10
  %3 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %2, ptr %1, 1, !dbg !10
  %4 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %3, i64 0, 2, !dbg !10
  %5 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %4, i64 2, 3, 0, !dbg !10
  %6 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %5, i64 2, 3, 1, !dbg !10
  %7 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %6, i64 2, 4, 0, !dbg !10
  %8 = insertvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %7, i64 1, 4, 1, !dbg !10
  %9 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 1, !dbg !10
  %10 = getelementptr double, ptr %9, i64 0, !dbg !10
  store double 1.000000e+00, ptr %10, align 8, !dbg !10
  %11 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 1, !dbg !10
  %12 = getelementptr double, ptr %11, i64 1, !dbg !10
  store double 2.000000e+00, ptr %12, align 8, !dbg !10
  %13 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 1, !dbg !10
  %14 = getelementptr double, ptr %13, i64 2, !dbg !10
  store double 3.000000e+00, ptr %14, align 8, !dbg !10
  %15 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 1, !dbg !10
  %16 = getelementptr double, ptr %15, i64 3, !dbg !10
  store double 4.000000e+00, ptr %16, align 8, !dbg !10
  br label %17, !dbg !11

17:                                               ; preds = %32, %0
  %18 = phi i64 [ 0, %0 ], [ %34, %32 ]
  %19 = icmp slt i64 %18, 2, !dbg !11
  br i1 %19, label %20, label %35, !dbg !11

20:                                               ; preds = %17
  br label %21, !dbg !11

21:                                               ; preds = %24, %20
  %22 = phi i64 [ 0, %20 ], [ %31, %24 ]
  %23 = icmp slt i64 %22, 2, !dbg !11
  br i1 %23, label %24, label %32, !dbg !11

24:                                               ; preds = %21
  %25 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 1, !dbg !11
  %26 = mul i64 %18, 2, !dbg !11
  %27 = add i64 %26, %22, !dbg !11
  %28 = getelementptr double, ptr %25, i64 %27, !dbg !11
  %29 = load double, ptr %28, align 8, !dbg !11
  %30 = call i32 (ptr, ...) @printf(ptr @frmt_spec, double %29), !dbg !11
  %31 = add i64 %22, 1, !dbg !11
  br label %21, !dbg !11

32:                                               ; preds = %21
  %33 = call i32 (ptr, ...) @printf(ptr @nl), !dbg !11
  %34 = add i64 %18, 1, !dbg !11
  br label %17, !dbg !11

35:                                               ; preds = %17
  %36 = extractvalue { ptr, ptr, i64, [2 x i64], [2 x i64] } %8, 0, !dbg !10
  call void @free(ptr %36), !dbg !10
  ret void, !dbg !12
}

!llvm.module.flags = !{!0}
!llvm.dbg.cu = !{!1}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = distinct !DICompileUnit(language: DW_LANG_C, file: !2, producer: "MLIR", isOptimized: true, runtimeVersion: 0, emissionKind: LineTablesOnly)
!2 = !DIFile(filename: "<unknown>", directory: "")
!3 = !DISubprogram(name: "free", linkageName: "free", scope: !2, file: !2, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagOptimized)
!4 = !DISubroutineType(cc: DW_CC_normal, types: !5)
!5 = !{}
!6 = !DISubprogram(name: "printf", linkageName: "printf", scope: !2, file: !2, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagOptimized)
!7 = !DISubprogram(name: "malloc", linkageName: "malloc", scope: !2, file: !2, line: 1, type: !4, scopeLine: 1, spFlags: DISPFlagOptimized)
!8 = distinct !DISubprogram(name: "main", linkageName: "main", scope: !9, file: !9, line: 4, type: !4, scopeLine: 1, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !1)
!9 = !DIFile(filename: "jit.toy", directory: "/opt/llvm-project/mlir/test/Examples/Toy/Ch6")
!10 = !DILocation(line: 5, column: 8, scope: !8)
!11 = !DILocation(line: 5, column: 2, scope: !8)
!12 = !DILocation(line: 4, column: 1, scope: !8)

