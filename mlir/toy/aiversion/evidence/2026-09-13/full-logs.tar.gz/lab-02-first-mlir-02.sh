"${TOY_BUILD}/bin/mlir-tblgen" -gen-dialect-decls /opt/llvm-project/mlir/examples/toy/Ch2/include/toy/Ops.td -I /opt/llvm-project/mlir/include
"${TOY_BUILD}/bin/mlir-tblgen" -gen-op-defs /opt/llvm-project/mlir/examples/toy/Ch2/include/toy/Ops.td -I /opt/llvm-project/mlir/include
"${TOY_BUILD}/bin/mlir-tblgen" -gen-op-doc /opt/llvm-project/mlir/examples/toy/Ch2/include/toy/Ops.td -I /opt/llvm-project/mlir/include
