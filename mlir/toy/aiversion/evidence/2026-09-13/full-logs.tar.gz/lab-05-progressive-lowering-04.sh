"$TOY_BUILD/bin/toyc-ch5" \
  "$TOY_ROOT/aiversion/examples/05-live-reshape.toy" \
  -emit=mlir -opt 2> "$TOY_LAB/ch5-live-reshape.mlir"
rg -n 'toy.transpose|toy.reshape|toy.print' "$TOY_LAB/ch5-live-reshape.mlir"

if "$TOY_BUILD/bin/toyc-ch5" \
  "$TOY_ROOT/aiversion/examples/05-live-reshape.toy" \
  -emit=mlir-affine 2> "$TOY_LAB/ch5-reshape-error.txt"; then
  printf '降级成功：请核对版本或规则是否已变化。\n'
else
  sed -n '1,90p' "$TOY_LAB/ch5-reshape-error.txt"
fi
