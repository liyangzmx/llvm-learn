test -x "$TOY_BUILD/bin/toyc-ch7"
test -x "$TOY_BUILD/bin/FileCheck"
"$TOY_BUILD/bin/toyc-ch7" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=ast 2> "$TOY_LAB/ch7-ast.txt"
"$TOY_BUILD/bin/toyc-ch7" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=mlir 2> "$TOY_LAB/ch7-raw.mlir"
"$TOY_BUILD/bin/toyc-ch7" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=mlir -opt 2> "$TOY_LAB/ch7-opt.mlir"
"$TOY_BUILD/bin/toyc-ch7" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-codegen.toy \
  -emit=mlir-affine 2> "$TOY_LAB/ch7-affine.mlir"
