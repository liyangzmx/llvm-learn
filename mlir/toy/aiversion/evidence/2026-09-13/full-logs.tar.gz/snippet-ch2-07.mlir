toy.func @f(%arg0: tensor<*xf64>) -> tensor<*xf64> {
  %0 = toy.transpose(%arg0 : tensor<*xf64>) to tensor<*xf64>
  %1 = toy.mul %0, %0 : tensor<*xf64>
  toy.return %1 : tensor<*xf64>
}
