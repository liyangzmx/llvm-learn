"$TOY_BUILD/bin/toyc-ch3" \
  "$TOY_ROOT/aiversion/examples/03-shared-transpose.mlir" \
  -emit=mlir 2> "$TOY_LAB/ch3-shared-before.mlir"
"$TOY_BUILD/bin/toyc-ch3" \
  "$TOY_ROOT/aiversion/examples/03-shared-transpose.mlir" \
  -emit=mlir -opt 2> "$TOY_LAB/ch3-shared-after.mlir"
rg -n 'toy.transpose|toy.print' "$TOY_LAB/ch3-shared-before.mlir" "$TOY_LAB/ch3-shared-after.mlir"
