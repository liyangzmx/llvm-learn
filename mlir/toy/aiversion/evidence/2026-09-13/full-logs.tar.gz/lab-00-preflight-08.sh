test -x "$TOY_BUILD/bin/toyc-ch1"
test -x "$TOY_BUILD/bin/FileCheck"
"$TOY_BUILD/bin/toyc-ch1" --help
