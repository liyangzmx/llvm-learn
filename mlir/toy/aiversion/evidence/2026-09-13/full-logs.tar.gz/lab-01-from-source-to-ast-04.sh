cp /opt/llvm-project/mlir/test/Examples/Toy/Ch1/ast.toy "$TOY_LAB/ch1-edit.toy"
