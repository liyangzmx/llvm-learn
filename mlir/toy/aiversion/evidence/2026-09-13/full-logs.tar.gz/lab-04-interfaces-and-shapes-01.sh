${TOY_BUILD}/bin/toyc-ch4 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch4/codegen.toy \
  -emit=mlir -opt
