module {
  toy.func @main() {
    %0 = toy.constant dense<[[1.0, 2.0], [3.0, 4.0]]>
         : tensor<2x2xf64>
    %1 = toy.transpose(%0 : tensor<2x2xf64>) to tensor<*xf64>
    toy.print %1 : tensor<*xf64>
    toy.return
  }
}
