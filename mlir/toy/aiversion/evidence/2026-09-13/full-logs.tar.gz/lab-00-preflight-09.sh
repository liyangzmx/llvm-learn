rg -n 'mlirGen\(VarDeclExprAST|create<ReshapeOp>|declare\(' \
  /opt/llvm-project/mlir/examples/toy/Ch2/mlir/MLIRGen.cpp
sed -n '379,405p' /opt/llvm-project/mlir/examples/toy/Ch2/mlir/MLIRGen.cpp
