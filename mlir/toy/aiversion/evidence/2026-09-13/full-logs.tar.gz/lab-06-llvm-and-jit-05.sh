"$TOY_BUILD/bin/toyc-ch6" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy \
  -emit=llvm -opt 2> "$TOY_LAB/ch6-llvm-opt.txt"
diff -u "$TOY_LAB/ch6-llvm.txt" "$TOY_LAB/ch6-llvm-opt.txt"
