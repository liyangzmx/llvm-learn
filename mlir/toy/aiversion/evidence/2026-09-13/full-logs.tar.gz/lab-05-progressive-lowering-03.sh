test -x "$TOY_BUILD/bin/toyc-ch5"
"$TOY_BUILD/bin/toyc-ch5" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch5/affine-lowering.mlir \
  -emit=mlir-affine 2> "$TOY_LAB/ch5-basic.mlir"
"$TOY_BUILD/bin/toyc-ch5" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch5/affine-lowering.mlir \
  -emit=mlir-affine -opt 2> "$TOY_LAB/ch5-fused.mlir"
rg -n 'memref.alloc|memref.dealloc|affine.for|affine.load|affine.store|arith.mulf|toy.print' \
  "$TOY_LAB/ch5-basic.mlir" "$TOY_LAB/ch5-fused.mlir"
