test -x "$TOY_BUILD/bin/toyc-ch3"
test -x "$TOY_BUILD/bin/mlir-tblgen"
test -x "$TOY_BUILD/bin/FileCheck"
