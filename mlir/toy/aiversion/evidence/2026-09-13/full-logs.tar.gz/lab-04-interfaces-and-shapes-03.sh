"$TOY_BUILD/bin/toyc-ch4" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch4/shape_inference.mlir \
  -emit=mlir -opt -mlir-disable-threading -mlir-print-ir-after-all \
  2> "$TOY_LAB/ch4-passes.log"
rg -n 'IR Dump|toy.generic_call|toy.cast|tensor<' "$TOY_LAB/ch4-passes.log"
