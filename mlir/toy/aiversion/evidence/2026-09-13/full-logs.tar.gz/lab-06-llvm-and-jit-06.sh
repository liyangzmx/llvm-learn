if "$TOY_BUILD/bin/toyc-ch6" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy \
  -emit=jit > "$TOY_LAB/ch6-result.txt" 2> "$TOY_LAB/ch6-jit-errors.txt"; then
  sed -n '1,5p' "$TOY_LAB/ch6-result.txt"
else
  sed -n '1,90p' "$TOY_LAB/ch6-jit-errors.txt"
fi
