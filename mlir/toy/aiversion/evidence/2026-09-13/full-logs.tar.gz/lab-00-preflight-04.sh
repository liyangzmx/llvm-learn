"$TOY_BUILD/bin/toyc-ch1" --help
"$TOY_BUILD/bin/toyc-ch1" /opt/llvm-project/mlir/test/Examples/Toy/Ch1/ast.toy -emit=ast
"$TOY_BUILD/bin/toyc-ch2" /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy -emit=mlir
