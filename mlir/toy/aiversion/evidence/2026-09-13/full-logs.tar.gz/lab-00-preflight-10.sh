if "$TOY_BUILD/bin/toyc-ch1" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch1/ast.toy \
  -emit=ast 2> "$TOY_LAB/ch1-ast.txt"; then
  sed -n '1,45p' "$TOY_LAB/ch1-ast.txt"
else
  sed -n '1,80p' "$TOY_LAB/ch1-ast.txt"
fi
