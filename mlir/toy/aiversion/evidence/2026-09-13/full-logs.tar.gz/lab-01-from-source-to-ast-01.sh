${TOY_BUILD}/bin/toyc-ch1 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch1/ast.toy \
  -emit=ast
