"${TOY_BUILD}/bin/toyc-ch7" /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-opt.mlir -emit=mlir 2> struct-before.mlir
"${TOY_BUILD}/bin/toyc-ch7" /opt/llvm-project/mlir/test/Examples/Toy/Ch7/struct-opt.mlir -emit=mlir -opt 2> struct-after.mlir
diff -u struct-before.mlir struct-after.mlir
