${TOY_BUILD}/bin/toyc-ch5 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch5/affine-lowering.mlir \
  -emit=mlir-affine -opt
