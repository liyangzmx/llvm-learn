test -x "$TOY_BUILD/bin/toyc-ch2"
"$TOY_BUILD/bin/toyc-ch2" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy \
  -emit=ast 2> "$TOY_LAB/ch2-ast.txt"
"$TOY_BUILD/bin/toyc-ch2" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy \
  -emit=mlir 2> "$TOY_LAB/ch2-custom.mlir"
"$TOY_BUILD/bin/toyc-ch2" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy \
  -emit=mlir -mlir-print-op-generic 2> "$TOY_LAB/ch2-generic.mlir"
