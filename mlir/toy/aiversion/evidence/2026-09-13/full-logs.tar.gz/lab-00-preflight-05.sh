"$TOY_BUILD/bin/toyc-ch2" /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy -emit=mlir 2> generated.mlir
"$TOY_BUILD/bin/toyc-ch2" generated.mlir -emit=mlir 2> reparsed.mlir
diff -u generated.mlir reparsed.mlir
