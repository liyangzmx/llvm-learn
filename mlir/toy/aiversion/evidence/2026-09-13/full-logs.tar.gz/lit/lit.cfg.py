lit_config.load_config(config, '/opt/llvm-project/build/tools/mlir/test/lit.site.cfg.py')
config.name = 'MLIR-Toy-existing-build'
config.test_source_root = '/opt/llvm-project/mlir/test/Examples/Toy'
config.test_exec_root = '/private/tmp/toy18-reviewed-verification/lit'
config.available_features.add('host-supports-jit')
