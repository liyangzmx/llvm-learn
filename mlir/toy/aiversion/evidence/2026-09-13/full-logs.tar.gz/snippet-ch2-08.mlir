module {
  func.func @main() {
    %x = "unknown.make"() : () -> i32
    return
  }
}
