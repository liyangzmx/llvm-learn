"$TOY_BUILD/bin/toyc-ch3" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch3/trivial_reshape.toy \
  -emit=mlir 2> "$TOY_LAB/ch3-reshape-before.mlir"
"$TOY_BUILD/bin/toyc-ch3" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch3/trivial_reshape.toy \
  -emit=mlir -opt 2> "$TOY_LAB/ch3-reshape-after.mlir"
diff -u "$TOY_LAB/ch3-reshape-before.mlir" "$TOY_LAB/ch3-reshape-after.mlir"
