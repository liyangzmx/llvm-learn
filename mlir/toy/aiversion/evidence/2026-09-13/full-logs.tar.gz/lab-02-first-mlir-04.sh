${TOY_BUILD}/bin/toyc-ch2 /opt/llvm-project/mlir/test/Examples/Toy/Ch2/codegen.toy -emit=mlir -mlir-print-debuginfo 2> codegen.mlir
${TOY_BUILD}/bin/toyc-ch2 codegen.mlir -emit=mlir 2> roundtrip.mlir
