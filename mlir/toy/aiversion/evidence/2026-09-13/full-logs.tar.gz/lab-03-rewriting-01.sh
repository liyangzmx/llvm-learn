${TOY_BUILD}/bin/toyc-ch3 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch3/transpose_transpose.toy \
  -emit=mlir -opt

${TOY_BUILD}/bin/toyc-ch3 \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch3/trivial_reshape.toy \
  -emit=mlir -opt
