test -x "$TOY_BUILD/bin/toyc-ch6"
for stage in mlir mlir-affine mlir-llvm llvm; do
  if ! "$TOY_BUILD/bin/toyc-ch6" \
    /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy \
    "-emit=$stage" 2> "$TOY_LAB/ch6-$stage.txt"; then
    printf '失败阶段：%s\n' "$stage"
    break
  fi
done
