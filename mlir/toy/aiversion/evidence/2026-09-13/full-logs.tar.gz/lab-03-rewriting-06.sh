"$TOY_BUILD/bin/mlir-tblgen" -gen-rewriters \
  /opt/llvm-project/mlir/examples/toy/Ch3/mlir/ToyCombine.td \
  -I /opt/llvm-project/mlir/include \
  -I /opt/llvm-project/mlir/examples/toy/Ch3/include \
  > "$TOY_LAB/ch3-generated.inc"
rg -n -A 7 'struct (RedundantReshapeOptPattern|ReshapeReshapeOptPattern|FoldConstantReshapeOptPattern)' \
  "$TOY_LAB/ch3-generated.inc"
