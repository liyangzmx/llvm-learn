module {
  toy.func @main() {
    %0 = toy.constant dense<4.000000e+00> : tensor<2x2xf64>
    toy.print %0 : tensor<2x2xf64>
    toy.return
  }
}
