test -x "$TOY_BUILD/bin/toyc-ch4"
test -x "$TOY_BUILD/bin/FileCheck"
"$TOY_BUILD/bin/toyc-ch4" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch4/shape_inference.mlir \
  -emit=mlir 2> "$TOY_LAB/ch4-no-opt.mlir"
"$TOY_BUILD/bin/toyc-ch4" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch4/shape_inference.mlir \
  -emit=mlir -opt 2> "$TOY_LAB/ch4-opt.mlir"
rg -n 'toy.generic_call|toy.cast|tensor<\*xf64>|toy.func private' "$TOY_LAB/ch4-no-opt.mlir"
sed -n '1,45p' "$TOY_LAB/ch4-opt.mlir"
