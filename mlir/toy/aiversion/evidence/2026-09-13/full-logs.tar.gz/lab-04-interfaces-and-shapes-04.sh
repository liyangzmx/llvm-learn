set -o pipefail
"$TOY_BUILD/bin/toyc-ch4" \
  /opt/llvm-project/mlir/test/Examples/Toy/Ch4/shape_inference.mlir \
  -emit=mlir -opt 2>&1 \
  | "$TOY_BUILD/bin/FileCheck" /opt/llvm-project/mlir/test/Examples/Toy/Ch4/shape_inference.mlir
