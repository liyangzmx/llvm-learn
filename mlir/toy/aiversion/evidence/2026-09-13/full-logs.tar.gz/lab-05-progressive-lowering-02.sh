"${TOY_BUILD}/bin/toyc-ch5" /opt/llvm-project/mlir/test/Examples/Toy/Ch5/affine-lowering.mlir -emit=mlir-affine 2> affine-basic.mlir
"${TOY_BUILD}/bin/toyc-ch5" /opt/llvm-project/mlir/test/Examples/Toy/Ch5/affine-lowering.mlir -emit=mlir-affine -opt 2> affine-opt.mlir
diff -u affine-basic.mlir affine-opt.mlir
