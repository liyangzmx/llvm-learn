"${TOY_BUILD}/bin/toyc-ch6" /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy -emit=mlir-affine 2> stage-affine.mlir
"${TOY_BUILD}/bin/toyc-ch6" /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy -emit=mlir-llvm 2> stage-llvm.mlir
"${TOY_BUILD}/bin/toyc-ch6" /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy -emit=llvm 2> stage.ll
"${TOY_BUILD}/bin/toyc-ch6" /opt/llvm-project/mlir/test/Examples/Toy/Ch6/jit.toy -emit=jit > result.txt 2> jit-errors.txt
